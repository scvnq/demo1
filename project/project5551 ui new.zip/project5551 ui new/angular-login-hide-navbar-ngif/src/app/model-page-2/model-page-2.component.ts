import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-model-page-2',
  templateUrl: './model-page-2.component.html',
  styleUrls: ['../css/bootstrap.css',
    '../css/style.css']
})
export class ModelPage2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
