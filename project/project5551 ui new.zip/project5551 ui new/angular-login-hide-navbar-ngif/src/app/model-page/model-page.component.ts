import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-model-page',
  templateUrl: './model-page.component.html',
  styleUrls: ['../css/bootstrap.css',
    '../css/style.css']
})
export class ModelPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
