import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-model-page-3',
  templateUrl: './model-page-3.component.html',
  styleUrls: ['../css/bootstrap.css',
    '../css/style.css']
})
export class ModelPage3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
