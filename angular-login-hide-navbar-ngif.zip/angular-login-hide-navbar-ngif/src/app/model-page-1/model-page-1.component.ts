import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-model-page-1',
  templateUrl: './model-page-1.component.html',
  styleUrls: ['../css/bootstrap.css',
    '../css/style.css']
})
export class ModelPage1Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
